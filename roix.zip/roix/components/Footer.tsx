import Link from "next/link";
import { Instagram, Linkedin } from "lucide-react";
export default function Footer() {
  return (<footer className="border-t border-white/10 px-5 py-14 md:px-10">
    <div className="mx-auto flex max-w-[1600px] flex-col gap-10 md:flex-row md:justify-between">
      <div><p className="text-4xl font-extrabold">ROIX</p><p className="mt-2 text-mist">Creative & Digital Agency</p></div>
      <nav aria-label="Footer" className="flex flex-wrap gap-x-8 gap-y-3 text-mist">
        {[["Services", "/#services"], ["Works", "/#work"], ["About", "/#about"], ["Contact", "/#contact"]].map(([l, h]) => <Link key={l} href={h} className="hover:text-white">{l}</Link>)}
      </nav>
      <div className="flex gap-4"><a href="https://instagram.com" aria-label="Instagram"><Instagram /></a><a href="https://linkedin.com" aria-label="LinkedIn"><Linkedin /></a></div>
    </div>
    <p className="mx-auto mt-10 max-w-[1600px] text-sm text-mist">© 2026 ROIX Agency</p>
  </footer>);
}
