import Link from "next/link";
import Magnetic from "./Magnetic";
type P = { href?: string; variant?: "solid" | "ghost"; children: React.ReactNode; type?: "button" | "submit"; disabled?: boolean };
export default function Button({ href, variant = "solid", children, type = "button", disabled }: P) {
  const c = "inline-flex min-h-12 items-center justify-center rounded-full px-7 text-base font-semibold transition-colors duration-300 disabled:opacity-50 " +
    (variant === "solid" ? "bg-white text-ink hover:bg-accent" : "border border-white/25 hover:border-white hover:bg-white/5");
  return (<Magnetic>{href ? <Link href={href} className={c}>{children}</Link> : <button type={type} disabled={disabled} className={c}>{children}</button>}</Magnetic>);
}
