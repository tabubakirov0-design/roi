import Image from "next/image";
import Link from "next/link";
import { Project, img } from "@/lib/projects";
export default function ProjectCard({ p, i }: { p: Project; i: number }) {
  return (<Link href={`/work/${p.slug}`} className={"group block " + (i % 2 ? "md:mt-24" : "")}>
    <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-graphite">
      <Image src={img(p.seed)} alt={`${p.name} — ${p.category} project preview`} fill sizes="(min-width:768px) 50vw, 100vw"
        className="object-cover transition-transform duration-700 ease-out group-hover:scale-105" />
    </div>
    <div className="mt-5 flex items-baseline justify-between gap-4"><h3 className="text-3xl font-bold">{p.name}</h3><span className="text-mist">{p.category}</span></div>
    <p className="mt-1 max-w-md text-mist">{p.blurb}</p>
  </Link>);
}
