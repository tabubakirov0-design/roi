"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import Button from "./Button";
const nav = [["Services", "/#services"], ["Works", "/#work"], ["About", "/#about"], ["Contacts", "/#contact"]];
export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 40);
    f(); window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);
  return (<>
    <header className={"fixed inset-x-0 top-0 z-40 transition-all duration-300 " + (scrolled ? "bg-ink/80 backdrop-blur-md py-3" : "py-6")}>
      <div className="mx-auto flex max-w-[1600px] items-center justify-between px-5 md:px-10">
        <Link href="/" className="text-2xl font-extrabold tracking-tight" aria-label="ROIX home">ROIX</Link>
        <nav aria-label="Main" className="hidden items-center gap-8 md:flex">
          {nav.map(([l, h]) => <Link key={l} href={h} className="text-sm text-mist transition-colors hover:text-white">{l}</Link>)}
          <Button href="/#contact">Start a project</Button>
        </nav>
        <button className="md:hidden p-2" aria-label="Open menu" onClick={() => setOpen(true)}><Menu /></button>
      </div>
    </header>
    <AnimatePresence>{open && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex flex-col bg-ink px-5 py-6">
        <button className="self-end p-2" aria-label="Close menu" onClick={() => setOpen(false)}><X /></button>
        <nav className="mt-10 flex flex-col gap-5">
          {nav.map(([l, h], i) => (<motion.div key={l} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.08 * i }}>
            <Link href={h} onClick={() => setOpen(false)} className="text-5xl font-extrabold">{l}</Link></motion.div>))}
        </nav>
        <div className="mt-auto" onClick={() => setOpen(false)}><Button href="/#contact">Start a project</Button></div>
      </motion.div>)}</AnimatePresence>
  </>);
}
