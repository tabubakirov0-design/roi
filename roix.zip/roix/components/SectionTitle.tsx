export default function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="text-5xl md:text-8xl font-extrabold tracking-tight leading-none">{children}</h2>;
}
