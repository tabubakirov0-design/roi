export type Project = { slug: string; name: string; category: string; year: string; client: string; blurb: string; challenge: string; solution: string; results: string; seed: string };
const t = (slug: string, name: string, category: string, year: string, client: string, blurb: string, challenge: string, solution: string, results: string): Project =>
  ({ slug, name, category, year, client, blurb, challenge, solution, results, seed: slug });
export const projects: Project[] = [
  t("roix", "ROIX", "Branding", "2026", "ROIX", "Our own identity system, built for motion.",
    "An agency identity that looks the same as everyone else’s helps nobody. We needed one that could move.",
    "A wordmark and type system designed for animation first, with one restrained accent colour.",
    "One identity across site, pitch decks and social, produced in half the usual time."),
  t("aura", "AURA", "Digital", "2025", "Aura Labs", "A digital product launch for a wellness brand.",
    "Aura was entering a market full of loud, clinical-looking apps and had no audience yet.",
    "We positioned it as a calm daily ritual and built the launch site, app onboarding and paid social together.",
    "Waitlist of 18,000 before launch and a 41% trial-to-paid conversion."),
  t("nova", "NOVA", "Identity", "2025", "Nova Pay", "Visual identity for a fintech challenger.",
    "Banks look alike. Nova needed to feel trustworthy without looking like a bank.",
    "A confident identity built on a simple geometric mark, plain language and a bold colour system.",
    "Brand recall up 3x in the first survey and a consistent look across 12 touchpoints."),
  t("motion", "MOTION", "Campaign", "2026", "Motion Co.", "An outdoor and social campaign for a sports label.",
    "A new collection, a small media budget and a crowded season of competing launches.",
    "One idea, movement frozen in a frame, shot once and adapted for billboards, video and social.",
    "4.2M organic views and the collection sold out in nine days."),
  t("form", "FORM", "Web", "2026", "Form Studio", "A design-led e-commerce website.",
    "The products were beautiful but the old store hid them behind slow pages and a confusing checkout.",
    "A fast, image-led storefront with a three-step checkout and editorial product pages.",
    "Load time cut by 62% and checkout completion up by 28%."),
  t("north", "NORTH", "Creative", "2025", "North Travel", "A creative platform for a travel brand.",
    "North sold trips but wanted to be remembered as a point of view, not a price list.",
    "A content platform of short films and guides, with a campaign built around real travellers.",
    "Direct bookings up 35% and a returning audience of 90,000 readers."),
];
export const img = (seed: string, w = 1200, h = 800) => `https://picsum.photos/seed/${seed}/${w}/${h}`;
