import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.tsx", "./components/**/*.tsx", "./sections/**/*.tsx"],
  theme: { extend: { colors: { ink: "#0A0A0A", graphite: "#1A1A1C", mist: "#8A8A90", accent: "#9DB4FF" },
    fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"] } } },
} satisfies Config;
