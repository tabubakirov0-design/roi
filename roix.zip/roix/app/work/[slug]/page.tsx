import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { projects, img } from "@/lib/projects";
import Reveal from "@/components/Reveal";
export const generateStaticParams = () => projects.map((p) => ({ slug: p.slug }));
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const p = projects.find((x) => x.slug === params.slug);
  return p ? { title: `${p.name} — ${p.category} | ROIX Agency`, description: p.blurb } : {};
}
export default function ProjectPage({ params }: { params: { slug: string } }) {
  const i = projects.findIndex((x) => x.slug === params.slug);
  if (i < 0) notFound();
  const p = projects[i], next = projects[(i + 1) % projects.length];
  return (<article className="px-5 pb-24 pt-36 md:px-10">
    <Reveal><h1 className="text-[18vw] font-extrabold leading-[0.9] tracking-tighter md:text-[12vw]">{p.name}</h1>
      <dl className="mt-10 grid grid-cols-3 gap-4 text-sm">{[["Category", p.category], ["Year", p.year], ["Client", p.client]].map(([k, v]) => <div key={k}><dt className="text-mist">{k}</dt><dd className="mt-1 text-lg">{v}</dd></div>)}</dl></Reveal>
    <div className="relative mt-14 aspect-[16/9] overflow-hidden rounded-2xl bg-graphite"><Image src={img(p.seed, 1600, 900)} alt={`${p.name} hero`} fill priority sizes="100vw" className="object-cover" /></div>
    <div className="mt-20 grid gap-14 md:grid-cols-2">{[["Overview", p.blurb], ["Challenge", p.challenge], ["Solution", p.solution], ["Results", p.results]].map(([h, t]) =>
      <Reveal key={h}><h2 className="text-3xl font-bold">{h}</h2><p className="mt-3 max-w-md text-mist">{t}</p></Reveal>)}</div>
    <div className="mt-20 grid gap-6 md:grid-cols-2">{[1, 2].map((n) => <div key={n} className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-graphite">
      <Image src={img(p.seed + n)} alt={`${p.name} gallery image ${n}`} fill loading="lazy" sizes="(min-width:768px) 50vw, 100vw" className="object-cover" /></div>)}</div>
    <Link href={`/work/${next.slug}`} className="group mt-28 block border-t border-white/10 pt-10">
      <span className="text-mist">Next project</span><span className="mt-2 block text-6xl font-extrabold transition-transform duration-500 group-hover:translate-x-4 md:text-9xl">{next.name} →</span></Link>
  </article>);
}
