export default function robots() { return { rules: { userAgent: "*", allow: "/" }, sitemap: "https://roix.agency/sitemap.xml" }; }
