import { projects } from "@/lib/projects";
export default function sitemap() {
  const b = "https://roix.agency";
  return [{ url: b }, ...projects.map((p) => ({ url: `${b}/work/${p.slug}` }))];
}
