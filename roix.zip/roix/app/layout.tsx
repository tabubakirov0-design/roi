import type { Metadata } from "next";
import { Manrope } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
const sans = Manrope({ subsets: ["latin", "cyrillic"], variable: "--font-sans" });
const description = "ROIX is a creative and digital agency helping ambitious brands grow, communicate and stand out.";
export const metadata: Metadata = {
  metadataBase: new URL("https://roix.agency"),
  title: "ROIX Agency — Creative & Digital Agency", description,
  openGraph: { title: "ROIX Agency — Creative & Digital Agency", description, type: "website", siteName: "ROIX Agency" },
  icons: { icon: "/icon.svg" },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className={sans.variable + " font-sans"}><Header /><main>{children}</main><Footer /></body></html>);
}
