import Hero from "@/sections/Hero";
import Services from "@/sections/Services";
import Work from "@/sections/Work";
import About from "@/sections/About";
import Process from "@/sections/Process";
import Why from "@/sections/Why";
import Testimonials from "@/sections/Testimonials";
import Contact from "@/sections/Contact";
import Button from "@/components/Button";
import Reveal from "@/components/Reveal";
export default function Home() {
  return (<>
    <Hero /><Services /><Work /><About /><Process /><Why /><Testimonials />
    <section className="px-5 md:px-10 py-32 md:py-48 text-center border-t border-white/10">
      <Reveal><h2 className="text-[11vw] md:text-[8vw] leading-[0.95] font-extrabold tracking-tight">HAVE A PROJECT<br />IN MIND?</h2>
      <p className="mt-6 text-2xl md:text-4xl text-accent">Let’s make it real.</p>
      <div className="mt-10"><Button href="#contact">Start a project →</Button></div></Reveal>
    </section>
    <Contact />
  </>);
}
