import Reveal from "@/components/Reveal";
import Counter from "@/components/Counter";
const areas = ["Strategy", "Creative", "Design", "Technology"];
export default function About() {
  return (<section id="about" className="border-t border-white/10 px-5 py-28 md:px-10 md:py-40">
    <Reveal><h2 className="max-w-6xl text-4xl font-extrabold leading-[1.02] tracking-tight md:text-7xl">WE DON’T JUST MAKE THINGS LOOK GOOD. <span className="text-mist">WE MAKE THEM MATTER.</span></h2></Reveal>
    <div className="mt-14 grid gap-12 md:grid-cols-2">
      <Reveal><p className="max-w-md text-lg text-mist">ROIX combines strategy, creativity, design and technology to create brands that connect with people and drive business.</p></Reveal>
      <Reveal delay={0.1}><ul className="grid grid-cols-2 gap-x-6 gap-y-3 text-2xl font-bold md:text-3xl">{areas.map((a) => <li key={a}>{a}</li>)}</ul></Reveal>
    </div>
    <dl className="mt-24 grid grid-cols-2 gap-y-12 md:grid-cols-4">
      {[[50, "+", "Projects"], [20, "+", "Brands"], [8, "+", "Markets"]].map(([n, s, l]) => (
        <div key={l as string}><dd className="text-6xl font-extrabold tracking-tighter md:text-8xl"><Counter to={n as number} suffix={s as string} /></dd><dt className="mt-2 text-mist">{l}</dt></div>))}
      <div><dd className="text-6xl font-extrabold tracking-tighter text-accent md:text-8xl" aria-label="Infinite">∞</dd><dt className="mt-2 text-mist">Ideas</dt></div>
    </dl>
  </section>);
}
