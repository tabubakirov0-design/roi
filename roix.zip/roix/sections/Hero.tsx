"use client";
import { motion, useReducedMotion } from "framer-motion";
import Button from "@/components/Button";
const lines = ["WE MAKE", "BRANDS", "IMPOSSIBLE", "TO IGNORE."];
export default function Hero() {
  const reduce = useReducedMotion();
  return (<section className="flex min-h-screen flex-col justify-end px-5 pb-16 pt-32 md:px-10">
    <h1 className="text-[15vw] font-extrabold leading-[0.88] tracking-tighter md:text-[9.5vw]" aria-label="We make brands impossible to ignore.">
      {lines.map((l, i) => (<span key={l} className="block overflow-hidden pb-[0.06em]" aria-hidden>
        <motion.span className={"block " + (i === 3 ? "text-accent" : "")} initial={reduce ? false : { y: "105%" }} animate={{ y: 0 }}
          transition={{ duration: 0.9, delay: 0.12 * i, ease: [0.22, 1, 0.36, 1] }}>{l}</motion.span></span>))}
    </h1>
    <motion.div initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9, duration: 0.8 }}
      className="mt-12 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
      <p className="max-w-md text-lg text-mist">ROIX is a creative and digital agency helping ambitious brands grow, communicate and stand out.</p>
      <div className="flex flex-col gap-3 sm:flex-row"><Button href="#contact">Start a project →</Button><Button href="#work" variant="ghost">View our work</Button></div>
    </motion.div>
  </section>);
}
