import Reveal from "@/components/Reveal";
import SectionTitle from "@/components/SectionTitle";
const steps = [["Discover", "We study your business, market and audience."], ["Strategy", "We define the positioning and the plan."], ["Create", "We design the identity, campaign and product."], ["Launch", "We ship fast and in every channel at once."], ["Grow", "We measure, learn and keep improving."]];
export default function Process() {
  return (<section className="px-5 py-28 md:px-10 md:py-40">
    <SectionTitle>HOW WE WORK</SectionTitle>
    <ol className="mt-16">{steps.map(([t, d], i) => (<li key={t}><Reveal>
      <div className="grid items-baseline gap-2 border-t border-white/10 py-8 md:grid-cols-[120px_1fr_1fr] md:gap-8">
        <span className="text-accent">{String(i + 1).padStart(2, "0")}</span>
        <h3 className="text-4xl font-bold md:text-5xl">{t}</h3><p className="max-w-sm text-mist">{d}</p></div></Reveal></li>))}</ol>
  </section>);
}
