import Reveal from "@/components/Reveal";
const pts = ["Strategic thinking", "Bold creative", "Premium design", "Fast execution", "Business-focused approach"];
export default function Why() {
  return (<section className="overflow-hidden px-5 py-28 md:px-10 md:py-40">
    <h2 className="text-xl text-mist md:text-2xl">WHY ROIX?</h2>
    <ul className="mt-10 space-y-2 md:space-y-4">{pts.map((p, i) => (<li key={p} className={i % 2 ? "md:pl-[18vw]" : ""}>
      <Reveal><span className={"block text-[9vw] font-extrabold leading-none tracking-tighter transition-colors duration-500 hover:text-accent md:text-[6.5vw] " + (i % 2 ? "text-white" : "text-white/40")}>{p}</span></Reveal></li>))}</ul>
  </section>);
}
