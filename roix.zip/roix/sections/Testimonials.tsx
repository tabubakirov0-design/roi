"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight } from "lucide-react";
const items = [
  ["ROIX rebuilt how our customers see us. Sales conversations got shorter within weeks.", "Anna Petrova", "CMO", "Aura Labs"],
  ["Sharp strategy, bold ideas and a team that ships on time. Rare combination.", "Daniel Kim", "Founder", "Nova Pay"],
  ["The campaign doubled our reach in a market we had just entered.", "Sara Lindholm", "Head of Brand", "Motion Co."],
  ["They treated our business goals as their own. The website pays for itself.", "Marco Rossi", "CEO", "Form Studio"],
];
export default function Testimonials() {
  const [i, setI] = useState(0);
  const go = (d: number) => setI((i + d + items.length) % items.length);
  const [q, n, r, c] = items[i];
  return (<section className="border-t border-white/10 px-5 py-28 md:px-10 md:py-40" aria-roledescription="carousel" aria-label="Client testimonials">
    <div className="min-h-[300px] md:min-h-[360px]"><AnimatePresence mode="wait">
      <motion.figure key={i} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -40 }} transition={{ duration: 0.4 }}>
        <blockquote className="max-w-5xl text-3xl font-bold leading-tight tracking-tight md:text-6xl">“{q}”</blockquote>
        <figcaption className="mt-8 text-mist"><span className="text-white">{n}</span>, {r}, {c}</figcaption>
      </motion.figure></AnimatePresence></div>
    <div className="mt-10 flex items-center gap-3">
      <button aria-label="Previous testimonial" onClick={() => go(-1)} className="grid h-12 w-12 place-items-center rounded-full border border-white/25 hover:bg-white/5"><ArrowLeft size={18} /></button>
      <button aria-label="Next testimonial" onClick={() => go(1)} className="grid h-12 w-12 place-items-center rounded-full border border-white/25 hover:bg-white/5"><ArrowRight size={18} /></button>
      <span className="ml-3 text-mist" aria-live="polite">{i + 1} / {items.length}</span>
    </div>
  </section>);
}
