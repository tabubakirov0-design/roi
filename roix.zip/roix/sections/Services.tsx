"use client";
import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import SectionTitle from "@/components/SectionTitle";
import { img } from "@/lib/projects";
const items = [
  ["Brand Strategy", "Positioning, audience and a clear story to build on."],
  ["Branding & Identity", "Names, logos and visual systems that hold together."],
  ["Digital Marketing", "Performance and growth campaigns tied to revenue."],
  ["Creative Advertising", "Big ideas, made for every channel."],
  ["Web Design & Development", "Fast, considered websites and products."],
  ["Social Media", "Content and communities people return to."],
  ["Content Production", "Photo, video and motion, end to end."],
];
export default function Services() {
  const [a, setA] = useState(0);
  return (<section id="services" className="px-5 py-28 md:px-10 md:py-40">
    <SectionTitle>WHAT WE DO</SectionTitle>
    <div className="mt-16 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
      <ul>{items.map(([n, d], i) => (<li key={n} className="border-t border-white/10 last:border-b">
        <button className="flex w-full items-start gap-5 py-6 text-left" aria-expanded={a === i} onClick={() => setA(i)} onMouseEnter={() => setA(i)} onFocus={() => setA(i)}>
          <span className={"w-10 pt-2 text-sm transition-colors " + (a === i ? "text-accent" : "text-mist")}>{a === i ? "→" : String(i + 1).padStart(2, "0")}</span>
          <span className="flex-1"><span className={"block text-2xl font-bold transition-all duration-300 md:text-4xl " + (a === i ? "translate-x-3" : "text-white/60")}>{n}</span>
            <AnimatePresence initial={false}>{a === i && (<motion.span initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="block overflow-hidden">
              <span className="block max-w-md pt-3 text-mist">{d}</span></motion.span>)}</AnimatePresence></span>
        </button></li>))}</ul>
      <div className="relative hidden aspect-[4/5] overflow-hidden rounded-2xl bg-graphite lg:block lg:sticky lg:top-28">
        <AnimatePresence mode="wait"><motion.div key={a} className="absolute inset-0" initial={{ opacity: 0, scale: 1.05 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
          <Image src={img("svc" + a, 800, 1000)} alt={`${items[a][0]} preview`} fill sizes="35vw" className="object-cover" /></motion.div></AnimatePresence>
      </div>
    </div>
  </section>);
}
