"use client";
import { useState } from "react";
import SectionTitle from "@/components/SectionTitle";
import Button from "@/components/Button";
const fields = [["name", "Name", "text"], ["company", "Company", "text"], ["email", "Email", "email"], ["phone", "Phone", "tel"]] as const;
const inp = "w-full border-b border-white/20 bg-transparent py-4 text-lg outline-none transition-colors focus:border-accent";
export default function Contact() {
  const [err, setErr] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    const x: Record<string, string> = {};
    if (!d.name?.trim()) x.name = "Enter your name.";
    if (!/^\S+@\S+\.\S+$/.test(d.email ?? "")) x.email = "Enter a valid email.";
    if ((d.message ?? "").trim().length < 10) x.message = "Tell us a bit more (10+ characters).";
    setErr(x);
    if (!Object.keys(x).length) setDone(true); // demo mode: connect your API route here
  }
  return (<section id="contact" className="border-t border-white/10 px-5 py-28 md:px-10 md:py-40">
    <SectionTitle>LET’S TALK</SectionTitle>
    <div className="mt-16 grid gap-16 lg:grid-cols-[1.4fr_1fr]">
      {done ? <p role="status" className="text-3xl font-bold md:text-5xl">Thank you. We’ll be in touch shortly.</p> : (
        <form onSubmit={submit} noValidate className="grid gap-6 md:grid-cols-2">
          {fields.map(([n, l, t]) => (<label key={n} className="block"><span className="text-sm text-mist">{l}</span>
            <input name={n} type={t} className={inp} aria-invalid={!!err[n]} />{err[n] && <span role="alert" className="text-sm text-accent">{err[n]}</span>}</label>))}
          <label className="block"><span className="text-sm text-mist">Project type</span>
            <select name="type" className={inp + " bg-ink"}>{["Branding", "Digital marketing", "Website", "Campaign", "Other"].map((o) => <option key={o}>{o}</option>)}</select></label>
          <label className="block"><span className="text-sm text-mist">Budget</span>
            <select name="budget" className={inp + " bg-ink"}>{["< $5k", "$5–15k", "$15–50k", "$50k+"].map((o) => <option key={o}>{o}</option>)}</select></label>
          <label className="block md:col-span-2"><span className="text-sm text-mist">Message</span>
            <textarea name="message" rows={4} className={inp} aria-invalid={!!err.message} />{err.message && <span role="alert" className="text-sm text-accent">{err.message}</span>}</label>
          <div className="md:col-span-2"><Button type="submit">Send inquiry</Button></div>
        </form>)}
      <ul className="space-y-4 text-xl">{[["Email", "mailto:hello@roix.agency"], ["WhatsApp", "https://wa.me/0000000000"], ["Instagram", "https://instagram.com"], ["LinkedIn", "https://linkedin.com"]].map(([l, h]) =>
        <li key={l}><a href={h} className="text-mist transition-colors hover:text-white">{l}</a></li>)}</ul>
    </div>
  </section>);
}
