import SectionTitle from "@/components/SectionTitle";
import ProjectCard from "@/components/ProjectCard";
import { projects } from "@/lib/projects";
export default function Work() {
  return (<section id="work" className="px-5 py-28 md:px-10 md:py-40">
    <SectionTitle>SELECTED WORK</SectionTitle>
    <div className="mt-16 grid gap-x-10 gap-y-16 md:grid-cols-2">{projects.map((p, i) => <ProjectCard key={p.slug} p={p} i={i} />)}</div>
  </section>);
}
