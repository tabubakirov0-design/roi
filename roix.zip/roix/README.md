# ROIX
npm install && npm run dev  → http://localhost:3000
Deploy: push to GitHub → vercel.com/new → Import → Deploy. Domain: Vercel → Settings → Domains → add, then set DNS records Vercel shows.
Edit: logo → components/Header.tsx + public/icon.svg | projects/images → lib/projects.ts | contacts → sections/Contact.tsx, components/Footer.tsx | domain → app/layout.tsx, app/sitemap.ts, app/robots.ts
